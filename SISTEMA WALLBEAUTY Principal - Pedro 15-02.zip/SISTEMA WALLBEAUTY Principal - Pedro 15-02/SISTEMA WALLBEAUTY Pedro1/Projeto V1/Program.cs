﻿using Projeto_V1;
using Projeto_V1.Forms;
using System;
using System.Windows.Forms;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        frmLogin loginForm = new frmLogin();
        if (loginForm.ShowDialog() == DialogResult.OK)
        {
            string nomeFuncionario = loginForm.ObterNomeFuncionarioLogado();
            Application.Run(new Principal(nomeFuncionario));
        }
    }
}

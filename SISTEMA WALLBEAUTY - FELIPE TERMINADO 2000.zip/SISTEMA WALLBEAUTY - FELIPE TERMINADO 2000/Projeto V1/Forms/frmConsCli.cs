﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmConsCli : Form
    {        
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;
        public frmConsCli()
        {
            InitializeComponent();
            buscarClientes();
        }

        private void buscarClientes()
        {
            try
            {
                bd.abrirConn();

                string sql = "SELECT Id,NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                dataGridView1.ReadOnly = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Construir a consulta SQL baseada nos campos preenchidos
                string sql = "SELECT Id,NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente";


                if (!string.IsNullOrEmpty(tbNome.Text))
                    sql += " AND cliente.NOME LIKE @Nome";

                if (!string.IsNullOrEmpty(tbCpf.Text))
                    sql += " AND cliente.CPF = @Cpf";

                if (!string.IsNullOrEmpty(tbEmail.Text))
                    sql += " AND cliente.EMAIL LIKE @Email";

                if (!string.IsNullOrEmpty(tbTel.Text))
                    sql += " AND cliente.Tel LIKE @Telefone";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                // Adicione parâmetros
                cmd.Parameters.AddWithValue("@Nome", "%" + tbNome.Text + "%");
                cmd.Parameters.AddWithValue("@Cpf", tbCpf.Text);
                cmd.Parameters.AddWithValue("@Email", "%" + tbEmail.Text + "%");
                cmd.Parameters.AddWithValue("@Telefone", "%" + tbTel.Text + "%");


                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar clientes: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();
                sql = "Delete from cliente where id=@cod";
                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@cod", Id);
                cmd.ExecuteNonQuery();
                buscarClientes();
                MessageBox.Show("Dados deletados!");
            }

            bd.fecharConn();
        }      

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtém o ID do cliente da célula clicada
                Id = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();

                // Obtém os valores das células da linha clicada
                string nome = dataGridView1.Rows[e.RowIndex].Cells["NOME"].Value.ToString();
                string telefone = dataGridView1.Rows[e.RowIndex].Cells["Telefone"].Value.ToString();
                string email = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                string cpf = dataGridView1.Rows[e.RowIndex].Cells["CPF"].Value.ToString();

                // Atribui os valores aos TextBoxes correspondentes
                tbNome.Text = nome;
                tbTel.Text = telefone;
                tbEmail.Text = email;
                tbCpf.Text = cpf;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Atualizando dados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    bd.abrirConn();

                    // Construir a consulta SQL de atualização
                    string sql = "UPDATE cliente SET NOME = @Nome, Tel = @Telefone, EMAIL = @Email, CPF = @Cpf WHERE id = @Id";

                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    // Adicionar parâmetros
                    cmd.Parameters.AddWithValue("@Nome", tbNome.Text);
                    cmd.Parameters.AddWithValue("@Telefone", tbTel.Text);
                    cmd.Parameters.AddWithValue("@Email", tbEmail.Text);
                    cmd.Parameters.AddWithValue("@Cpf", tbCpf.Text);
                    cmd.Parameters.AddWithValue("@Id", Id);

                    // Executar o comando de atualização
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Dados atualizados com sucesso!");
                        // Atualiza a exibição dos clientes
                        buscarClientes();
                    }
                    else
                    {
                        MessageBox.Show("Nenhum cliente foi atualizado. Verifique o ID do cliente.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao atualizar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    bd.fecharConn();
                }
            }

        }
    }
}

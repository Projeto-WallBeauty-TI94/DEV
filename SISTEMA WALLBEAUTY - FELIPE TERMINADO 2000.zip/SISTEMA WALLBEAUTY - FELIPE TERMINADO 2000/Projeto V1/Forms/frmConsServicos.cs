﻿using MySqlConnector;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmConsServicos : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;

        public frmConsServicos()
        {
            InitializeComponent();
            buscarServicos();
        }
        private void limpaCampos()
            {
            tbNome.Text = "";
            tbDesc.Text = "";
            tbPreco.Text = "";
            }
        private void buscarServicos()
        {
            try
            {
                bd.abrirConn();

                string sql = "SELECT Id, NOME AS Nome, DESCRICAO AS Descrição, PRECO AS Preço FROM servico ORDER BY NOME ASC";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dgvServicos.DataSource = dataTable;
                dgvServicos.ReadOnly = true;

                // Ajuste do tamanho das colunas
                dgvServicos.Columns["Id"].Width = 20; // Define a largura da coluna Id como 20 pixels
                dgvServicos.Columns["Descrição"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells; // Ajusta a largura da coluna Descrição com base no conteúdo das células
                dgvServicos.Columns["Preço"].Width = 55; // Define a largura da coluna Preço como 55 pixels
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }        
        private void button3_Click(object sender, EventArgs e)
        {
            {
                DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    bd.abrirConn();
                    sql = "Delete from servico where id=@cod";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@cod", Id);
                    cmd.ExecuteNonQuery();
                    buscarServicos();
                    MessageBox.Show("Dados deletados!");
                }
                buscarServicos();
                limpaCampos();
                bd.fecharConn();
            }
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Construir a consulta SQL baseada nos campos preenchidos
                string sql = "SELECT Id, NOME AS Nome, DESCRICAO AS Descrição, PRECO AS Preço FROM servico WHERE 1=1";

                if (!string.IsNullOrEmpty(tbNome.Text))
                    sql += " AND NOME LIKE @Nome";

                if (!string.IsNullOrEmpty(tbPreco.Text))
                    sql += " AND PRECO = @Preco";

                if (!string.IsNullOrEmpty(tbDesc.Text))
                    sql += " AND DESCRICAO LIKE @Descricao";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                // Adicionar parâmetros
                cmd.Parameters.AddWithValue("@Nome", "%" + tbNome.Text + "%");
                cmd.Parameters.AddWithValue("@Preco", tbPreco.Text);
                cmd.Parameters.AddWithValue("@Descricao", "%" + tbDesc.Text + "%");

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dgvServicos.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar serviços: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
                limpaCampos();
            }
        }
        private void dgvServicos_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvServicos.Rows[e.RowIndex];

                // Obtendo o ID do serviço da célula clicada
                Id = row.Cells["Id"].Value.ToString();

                // Preenchendo os campos de texto com os dados do serviço
                tbNome.Text = row.Cells["Nome"].Value.ToString();
                tbPreco.Text = row.Cells["Preço"].Value.ToString();
                tbDesc.Text = row.Cells["Descrição"].Value.ToString();

            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Verificar se os campos estão vazios
                if (string.IsNullOrWhiteSpace(tbNome.Text) || string.IsNullOrWhiteSpace(tbDesc.Text) || string.IsNullOrWhiteSpace(tbPreco.Text))
                {
                    MessageBox.Show("Por favor, preencha todos os campos antes de atualizar.", "Campos vazios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Construir a consulta SQL de atualização
                    string sql = "UPDATE servico SET NOME = @Nome, DESCRICAO = @Descricao, PRECO = @Preco WHERE Id = @Id";

                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    // Adicionar parâmetros
                    cmd.Parameters.AddWithValue("@Nome", tbNome.Text);
                    cmd.Parameters.AddWithValue("@Descricao", tbDesc.Text);
                    cmd.Parameters.AddWithValue("@Preco", tbPreco.Text);
                    cmd.Parameters.AddWithValue("@Id", Id);

                    // Executar o comando de atualização
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Dados atualizados com sucesso!");
                        // Atualizar a exibição dos serviços
                        buscarServicos();
                    }
                    else
                    {
                        MessageBox.Show("Nenhum serviço foi atualizado. Verifique o ID do serviço.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao atualizar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
                limpaCampos();
            }

        }

    }
}

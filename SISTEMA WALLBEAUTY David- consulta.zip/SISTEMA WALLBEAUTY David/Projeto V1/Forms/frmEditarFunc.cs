﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string id;

        public object Id { get; private set; }

        public frmEditarFunc()
        {
            InitializeComponent();
        }

        private int idFuncionario;

      
       


        private void listar()
        {
            bd.abrirConn();
            sql = "Select ID, NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,DATA_NASCIMENTO,DATA_CONTRATACAO from funcionario order by nome asc";
            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            // Verifica se o ID do funcionário é válido
            if (idFuncionario != 0)
            {
                DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        bd.abrirConn();
                        string sql = "DELETE FROM funcionario WHERE id = @cod";
                        MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                        cmd.Parameters.AddWithValue("@cod", idFuncionario);
                        cmd.ExecuteNonQuery();
                        bd.fecharConn();

                        MessageBox.Show("Dados excluídos com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao excluir dados: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Operação cancelada.");
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um ID válido.");
            }
        }


        private void btnAlterar_Click(object sender, EventArgs e)
        {
            // Verifica se o campo de ID não está vazio
            if (!string.IsNullOrEmpty(tbId.Text))
            {
                try
                {
                    // Converta o ID do texto para um número inteiro
                    if (int.TryParse(tbId.Text, out int id))
                    {
                        bd.abrirConn();
                        string sql = "UPDATE funcionario SET nome=@nome, sobrenome=@sobrenome, cpf=@cpf, email=@email, telefone=@telefone, cep=@cep, salario=@salario WHERE ID=@id";
                        MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                        cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                        cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                        cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                        cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                        cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                        cmd.ExecuteNonQuery();
                        bd.fecharConn();
                        MessageBox.Show("Funcionário atualizado com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira um ID válido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar funcionário: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o ID do funcionário que deseja atualizar.");
            }
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            listar();
        }

        private void frmEditarFunc_Load(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }


        // Evento TextChanged do TextBox nome
        private void nome_TextChanged(object sender, EventArgs e)
        {
            // Verifica se o texto no TextBox pode ser convertido para um número inteiro
            if (int.TryParse(nome.Text, out int id))
            {
                // Se a conversão for bem-sucedida, armazena o valor do ID
                idFuncionario = id;
            }
            else
            {
                // Se a conversão falhar, define o ID como 0 ou outra ação apropriada
                idFuncionario = 0;
            }
        }

        private void tbId_TextChanged(object sender, EventArgs e)
        {
            // Atualiza o valor do ID sempre que o texto no tbId for alterado
            // Verifica se o texto pode ser convertido para um número inteiro
            if (int.TryParse(tbId.Text, out int id))
            {
                // Se a conversão for bem-sucedida, atualiza o valor do ID
                idFuncionario = id;
            }
            else
            {
                // Se a conversão falhar, define o ID como 0 ou outra ação apropriada
                idFuncionario = 0;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

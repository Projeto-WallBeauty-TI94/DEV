﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmCadastroFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string Id;
        public frmCadastroFunc()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            if ((tbNome.Text == "") && (tbSobrenome.Text == ""))
            {
                MessageBox.Show("Insira dados válidos.");
            }
            else
            {
                sql = "insert into funcionario (NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,DATA_NASCIMENTO,DATA_CONTRATACAO)values(@nome,@sobrenome,@cpf,@email,@telefone,@cep,@salario,@data_nascimento,@data_contratacao)"; //os '@' identifica que são parâmetros
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                cmd.Parameters.AddWithValue("@data_nascimento", dateNascimento.Value);
                cmd.Parameters.AddWithValue("@data_contratacao", dateAdmissao.Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Dados inseridos");

            }
            bd.fecharConn();
        }
    }
}

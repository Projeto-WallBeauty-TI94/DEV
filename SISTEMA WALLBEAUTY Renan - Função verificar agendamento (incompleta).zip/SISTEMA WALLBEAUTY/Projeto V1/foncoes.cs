﻿using MySqlConnector;
using Projeto_V1.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1
{



    public class Funcoes
    {
        public static void InserirCliente(string nome, string cpf, string tel, string email)
        {

            banco bd = new banco();
            string sql;

            try
            {
                bd.abrirConn();

                if (string.IsNullOrWhiteSpace(nome) && string.IsNullOrWhiteSpace(cpf))
                {
                    MessageBox.Show("Insira dados válidos.");
                }
                else
                {
                    sql = "insert into cliente (nome, cpf, tel, email) values(@nome, @cpf, @tel, @email)";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@tel", tel);
                    cmd.Parameters.AddWithValue("@email", email);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir dados: " + ex.Message);
            }
            finally
            {
                bd.fecharConn();
            }



        }
        public bool VerificarExistenciaAgendamento(string funcionario, string cliente, string servico, DateTime data, string hora)
        {
            string sqlVerificar = @"
        SELECT COUNT(*) 
        FROM agendamento 
        WHERE FUNCIONARIO_ID = (SELECT ID FROM funcionario WHERE nome = @Funcionario) 
        AND FK_CLIENTE_ID = (SELECT ID FROM cliente WHERE nome = @Cliente) 
        AND FK_SERVICO_ID = (SELECT ID FROM servico WHERE nome = @Servico) 
        AND DATA_AGENDAMENTO = @Data 
        AND HORA_AGENDAMENTO = @Hora";

            MySqlCommand cmdVerificar = new MySqlCommand(sqlVerificar, bd.conecta);
            cmdVerificar.Parameters.AddWithValue("@Funcionario", funcionario);
            cmdVerificar.Parameters.AddWithValue("@Cliente", cliente);
            cmdVerificar.Parameters.AddWithValue("@Servico", servico);
            cmdVerificar.Parameters.AddWithValue("@Data", data);
            cmdVerificar.Parameters.AddWithValue("@Hora", hora);

            int count = Convert.ToInt32(cmdVerificar.ExecuteScalar());

            return count > 0;
        }
    }




}

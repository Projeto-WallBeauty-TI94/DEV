﻿using Projeto_V1.Forms;
using Projeto_V1;
using System.Windows.Forms;
using System;

static class Program
{
    /// <summary>
    /// Ponto de entrada principal para o aplicativo.
    /// </summary>
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        Principal loginForm = new Principal();
        if (loginForm.ShowDialog() == DialogResult.OK)
        {
            Application.Run(new Principal());
        }
    }
}

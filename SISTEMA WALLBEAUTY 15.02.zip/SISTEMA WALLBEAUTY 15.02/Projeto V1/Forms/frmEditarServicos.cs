﻿using MySqlConnector;
using System;
using System.Data;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmEditarServicos : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;
        public frmEditarServicos()
        {
            InitializeComponent();
            buscarServicos();
        }
        private void limpaCampos()
        {
            tbNome.Text = "";
            tbDesc.Text = "";
            tbPreco.Text = "";
        }
        private void buscarServicos()
        {
            try
            {
                bd.abrirConn();

                string sql = "SELECT Id, NOME AS Nome, DESCRICAO AS Descrição, PRECO AS Preço FROM servico ORDER BY NOME ASC";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dgvServicos.DataSource = dataTable;
                dgvServicos.ReadOnly = true;

                // Ajuste do tamanho das colunas
                dgvServicos.Columns["Id"].Width = 20; // Define a largura da coluna Id como 20 pixels
                dgvServicos.Columns["Descrição"].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells; // Ajusta a largura da coluna Descrição com base no conteúdo das células
                dgvServicos.Columns["Preço"].Width = 55; // Define a largura da coluna Preço como 55 pixels
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }
        private void frmEditarServicos_Load(object sender, EventArgs e)
        {
            dgvServicos.CellClick += dgvServicos_CellClick;
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Construir a consulta SQL baseada nos campos preenchidos
                string sql = "SELECT Id, NOME AS Nome, DESCRICAO AS Descrição, PRECO AS Preço FROM servico WHERE 1=1";

                if (!string.IsNullOrEmpty(tbNome.Text))
                    sql += " AND NOME LIKE @Nome";

                if (!string.IsNullOrEmpty(tbPreco.Text))
                    sql += " AND PRECO = @Preco";

                if (!string.IsNullOrEmpty(tbDesc.Text))
                    sql += " AND DESCRICAO LIKE @Descricao";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                // Adicionar parâmetros
                cmd.Parameters.AddWithValue("@Nome", "%" + tbNome.Text + "%");
                cmd.Parameters.AddWithValue("@Preco", tbPreco.Text);
                cmd.Parameters.AddWithValue("@Descricao", "%" + tbDesc.Text + "%");

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dgvServicos.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar serviços: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
                limpaCampos();
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Verificar se os campos estão vazios ou têm valor igual a zero
                if (string.IsNullOrWhiteSpace(tbNome.Text) ||
                    string.IsNullOrWhiteSpace(tbDesc.Text) ||
                    string.IsNullOrWhiteSpace(tbPreco.Text) ||
                    Convert.ToDecimal(tbPreco.Text) == 0)
                {
                    MessageBox.Show("Por favor, preencha todos os campos corretamente antes de atualizar.", "Campos inválidos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Construir a consulta SQL de atualização
                    string sql = "UPDATE servico SET NOME = @Nome, DESCRICAO = @Descricao, PRECO = @Preco WHERE Id = @Id";

                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    // Adicionar parâmetros
                    cmd.Parameters.AddWithValue("@Nome", tbNome.Text);
                    cmd.Parameters.AddWithValue("@Descricao", tbDesc.Text);
                    cmd.Parameters.AddWithValue("@Preco", tbPreco.Text);
                    cmd.Parameters.AddWithValue("@Id", Id);

                    // Executar o comando de atualização
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Dados atualizados com sucesso!");
                        // Atualizar a exibição dos serviços
                        buscarServicos();
                    }
                    else
                    {
                        MessageBox.Show("Nenhum serviço foi atualizado. Verifique o ID do serviço.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao atualizar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
                limpaCampos();
            }
        }


        private void btnDeletar_Click(object sender, EventArgs e)
        {
            {
                DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    bd.abrirConn();
                    sql = "Delete from servico where id=@cod";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@cod", Id);
                    cmd.ExecuteNonQuery();
                    buscarServicos();
                    MessageBox.Show("Dados deletados!");
                }
                buscarServicos();
                limpaCampos();
                bd.fecharConn();
            }
        }

        private void dgvServicos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificar se o clique ocorreu em uma célula válida
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obter o ID da linha clicada
                Id = dgvServicos.Rows[e.RowIndex].Cells["Id"].Value.ToString();

                // Preencher os campos com os valores correspondentes
                tbNome.Text = dgvServicos.Rows[e.RowIndex].Cells["Nome"].Value.ToString();
                tbDesc.Text = dgvServicos.Rows[e.RowIndex].Cells["Descrição"].Value.ToString();
                tbPreco.Text = dgvServicos.Rows[e.RowIndex].Cells["Preço"].Value.ToString();
            }
            else
            {
                // Limpar os campos se nenhuma célula válida estiver clicada
                limpaCampos();
            }
        }

        private void dgvServicos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvServicos.SelectedRows.Count > 0)
            {
                // Obter o ID da linha selecionada
                Id = dgvServicos.SelectedRows[0].Cells["Id"].Value.ToString();

                // Preencher os campos com os valores correspondentes
                tbNome.Text = dgvServicos.SelectedRows[0].Cells["Nome"].Value.ToString();
                tbDesc.Text = dgvServicos.SelectedRows[0].Cells["Descrição"].Value.ToString();
                tbPreco.Text = dgvServicos.SelectedRows[0].Cells["Preço"].Value.ToString();
            }
            else
            {
                // Limpar os campos se nenhuma linha estiver selecionada
                limpaCampos();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string id;

        public object Id { get; private set; }

        public frmEditarFunc()
        {
            InitializeComponent();
            tbSenha.PasswordChar = '*';
            listar();
        }

        private int idFuncionario;
        private void LimparCampos()
        {
            tbNome.Text = "";
            tbCpf.Text = "";
            tbTelefone.Text = "";
            tbEmail.Text = "";
            tbCep.Text = "";
            tbSobrenome.Text = "";
            tbSalario.Text = "";
            tbSenha.Text = "";
            tbId.Text = "";
        }

        private void listar()
        {
            bd.abrirConn();
            sql = "Select ID, NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,DATA_NASCIMENTO,DATA_CONTRATACAO from funcionario order by nome asc";
            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            // Verifica se o ID do funcionário é válido

            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    bd.abrirConn();
                    string sql = "DELETE FROM funcionario WHERE id = @cod";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@cod", tbId.Text);
                    cmd.ExecuteNonQuery();
                    listar();
                    LimparCampos();
                    bd.fecharConn();
                    MessageBox.Show("Dados excluídos com sucesso!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao excluir dados: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Operação cancelada.");
            }
        }
        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            // Verifica se o campo de ID não está vazio
            if (!string.IsNullOrEmpty(tbId.Text))
            {
                try
                {
                    // Converta o ID do texto para um número inteiro
                    if (int.TryParse(tbId.Text, out int id))
                    {
                        // Verificar se há campos vazios ou valores iguais a zero
                        if (CamposValidos())
                        {
                            bd.abrirConn();

                            // Criptografar a senha usando SHA256
                            string senhaCriptografada = CriptografarSenha(tbSenha.Text);

                            string sql = "UPDATE funcionario SET nome=@nome, sobrenome=@sobrenome, cpf=@cpf, email=@email, telefone=@telefone, cep=@cep, senha=@senha, salario=@salario WHERE ID=@id";
                            MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                            cmd.Parameters.AddWithValue("@id", id);
                            cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                            cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                            cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                            cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                            cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                            cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                            cmd.Parameters.AddWithValue("@senha", senhaCriptografada); // Use a senha criptografada
                            cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                            cmd.ExecuteNonQuery();
                            LimparCampos();
                            listar();
                            bd.fecharConn();
                            MessageBox.Show("Funcionário atualizado com sucesso!");
                        }
                        else
                        {
                            MessageBox.Show("Por favor, preencha todos os campos corretamente antes de atualizar.", "Campos inválidos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira um ID válido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar funcionário: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o ID do funcionário que deseja atualizar.");
            }
        }

        private bool CamposValidos()
        {
            // Verifica se há campos vazios ou valores iguais a zero
            return !string.IsNullOrWhiteSpace(tbNome.Text) &&
                   !string.IsNullOrWhiteSpace(tbSobrenome.Text) &&
                   !string.IsNullOrWhiteSpace(tbCpf.Text) &&
                   !string.IsNullOrWhiteSpace(tbEmail.Text) &&
                   !string.IsNullOrWhiteSpace(tbTelefone.Text) &&
                   !string.IsNullOrWhiteSpace(tbCep.Text) &&
                   !string.IsNullOrWhiteSpace(tbSalario.Text) &&
                   Convert.ToDecimal(tbSalario.Text) != 0;
        }
        private string CriptografarSenha(string senha)
        {
            using (SHA256 sha256 = SHA256Managed.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(senha);
                byte[] hash = sha256.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica se o clique foi em uma célula válida
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extrai os valores das células e os coloca nos TextBox correspondentes
                tbId.Text = row.Cells["id"].Value.ToString();
                tbNome.Text = row.Cells["nome"].Value.ToString();
                tbSobrenome.Text = row.Cells["sobrenome"].Value.ToString();
                tbCpf.Text = row.Cells["cpf"].Value.ToString();
                tbEmail.Text = row.Cells["email"].Value.ToString();
                tbTelefone.Text = row.Cells["telefone"].Value.ToString();
                tbCep.Text = row.Cells["cep"].Value.ToString();
                tbSalario.Text = row.Cells["salario"].Value.ToString();
                // Adicione mais TextBox conforme necessário para as colunas adicionais
            }
        }
        private void btnConsulta_Click_1(object sender, EventArgs e)
        {
            // Verifica se o campo de pesquisa não está vazio
            if (!string.IsNullOrEmpty(tbConsulta.Text))
            {
                try
                {
                    bd.abrirConn();

                    // Construir a consulta SQL baseada nos campos de pesquisa
                    string sql = "SELECT ID, NOME, SOBRENOME, CPF, EMAIL, TELEFONE, CEP, SALARIO, DATA_NASCIMENTO, DATA_CONTRATACAO FROM funcionario WHERE 1=1";

                    // Adiciona condições para cada campo
                    sql += " AND (NOME LIKE @termo OR SOBRENOME LIKE @termo OR CPF LIKE @termo OR EMAIL LIKE @termo OR TELEFONE LIKE @termo OR CEP LIKE @termo OR SALARIO LIKE @termo)";

                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@termo", "%" + tbConsulta.Text + "%"); // Pesquisa parcial do termo em qualquer coluna

                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Nenhum registro encontrado.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao consultar funcionário: " + ex.Message);
                }
                finally
                {
                    bd.fecharConn();
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira um termo para pesquisar.");
            }

            // Chama o método listar() após a consulta
            listar();
        }



        private void tbId_TextChanged(object sender, EventArgs e)
        {
            // Atualiza o valor do ID sempre que o texto no tbId for alterado
            // Verifica se o texto pode ser convertido para um número inteiro
            if (int.TryParse(tbId.Text, out int id))
            {
                // Se a conversão for bem-sucedida, atualiza o valor do ID
                idFuncionario = id;
            }
            else
            {
                // Se a conversão falhar, define o ID como 0 ou outra ação apropriada
                idFuncionario = 0;
            }
        }
    }
}

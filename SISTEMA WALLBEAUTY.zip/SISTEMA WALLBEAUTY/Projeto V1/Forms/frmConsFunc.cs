﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmConsFunc : Form
    {

        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string id;
        public frmConsFunc()
        {
            InitializeComponent();
        }

        private void listar()
        {
            bd.abrirConn();
            sql = "Select NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,DATA_NASCIMENTO,DATA_CONTRATACAO from funcionario order by nome asc";
            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }
        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            listar();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

            if (dataGridView1.SelectedRows.Count > 0) // Verifica se há uma linha selecionada
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row); // Remove a linha selecionada do DataGridView
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0) // Verifica se há uma linha selecionada
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0]; // Obtém a linha selecionada
                row.Cells["nome"].Value = tbNome.Text; // Atualiza o valor da coluna 1
                row.Cells["sobrenome"].Value = tbSobrenome.Text; // Atualiza o valor da coluna 2
                row.Cells["cpf"].Value = tbCpf.Text;
                row.Cells["email"].Value = tbEmail.Text;
                row.Cells["telefone"].Value = tbTelefone.Text;
                row.Cells["cep"].Value = tbCep.Text;
                row.Cells["salario"].Value = tbSalario.Text;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica se o clique foi em uma célula válida
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extrai os valores das células e os coloca nos TextBox correspondentes
                tbNome.Text = row.Cells["nome"].Value.ToString();
                tbSobrenome.Text = row.Cells["sobrenome"].Value.ToString();
                tbCpf.Text = row.Cells["cpf"].Value.ToString();
                tbEmail.Text = row.Cells["email"].Value.ToString();
                tbTelefone.Text = row.Cells["telefone"].Value.ToString();
                tbCep.Text = row.Cells["cep"].Value.ToString();
                tbSalario.Text = row.Cells["salario"].Value.ToString();
                // Adicione mais TextBox conforme necessário para as colunas adicionais
            }
        }
    }
}

﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmConsCli : Form
    {        
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string id;
        public frmConsCli()
        {
            InitializeComponent();
            buscarClientes();
        }

        private void limpaTb()
        {
            tbNome.Text = "";
            tbCpf.Text = "";
            tbTel.Text = "";
            tbEmail.Text = "";
        }
        private void buscarClientes()
        {
            try
            {
                bd.abrirConn();

                string sql = "SELECT ID,NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                dataGridView1.ReadOnly = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Construir a consulta SQL baseada nos campos preenchidos
                string sql = "SELECT ID,NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente";

                if (!string.IsNullOrEmpty(tbNome.Text))
                    sql += " AND cliente.NOME LIKE @Nome";

                if (!string.IsNullOrEmpty(tbCpf.Text))
                    sql += " AND cliente.CPF = @Cpf";

                if (!string.IsNullOrEmpty(tbEmail.Text))
                    sql += " AND cliente.EMAIL LIKE @Email";

                if (!string.IsNullOrEmpty(tbTel.Text))
                    sql += " AND cliente.TEL LIKE @Telefone";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                // Adicione parâmetros
                cmd.Parameters.AddWithValue("@Nome", "%" + tbNome.Text + "%");
                cmd.Parameters.AddWithValue("@Cpf", tbCpf.Text);
                cmd.Parameters.AddWithValue("@Email", "%" + tbEmail.Text + "%");
                cmd.Parameters.AddWithValue("@Telefone", "%" + tbTel.Text + "%");


                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar clientes: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bd.abrirConn(); // Abre a conexão antes de executar o código principal

            if ((tbNome.Text == "") || (tbCpf.Text == "") || (tbEmail.Text == "") || (tbEmail.Text == ""))
            {
                MessageBox.Show("Insira dados válidos.");
            }

            // Restante do código
            sql = "update cliente set nome=@nome, cpf=@cpf , TEL=@tel, EMAIL=@email where id=@id";
            MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@nome", tbNome.Text);
            cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
            cmd.Parameters.AddWithValue("@tel", tbTel.Text);
            cmd.Parameters.AddWithValue("@email", tbEmail.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            //limpaTb();

            buscarClientes();

            bd.fecharConn(); // Fecha a conexão após a execução do código
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
                // Certifique-se de que a célula clicada é válida e não é o cabeçalho da coluna
                if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
                {
                // Obtém o ID do usuário selecionado na DataGridView
                id = dataGridView1.CurrentRow.Cells[0].Value.ToString();

                // Consulta no banco de dados para obter os dados do usuário pelo ID
                bd.abrirConn();
                    string sql = "SELECT NOME, CPF, TEL, EMAIL FROM cliente WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@id", id);

                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Atribui os dados aos campos
                            tbNome.Text = reader["NOME"].ToString();
                            tbCpf.Text = reader["CPF"].ToString();
                            tbTel.Text = reader["TEL"].ToString();
                            tbEmail.Text = reader["EMAIL"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Usuário não encontrado.");
                        }
                    }

                    bd.fecharConn();
                
            }


        }
    }
}

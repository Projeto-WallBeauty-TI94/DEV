﻿using MySqlConnector;
using Projeto_V1.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1
{



    public class Funcoes
    {
        public static void InserirCliente(string nome, string cpf, string tel, string email)
        {

            banco bd = new banco();
            string sql;

            try
            {
                bd.abrirConn();

                if (string.IsNullOrWhiteSpace(nome) && string.IsNullOrWhiteSpace(cpf))
                {
                    MessageBox.Show("Insira dados válidos.");
                }
                else
                {
                    sql = "insert into cliente (nome, cpf, tel, email) values(@nome, @cpf, @tel, @email)";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@tel", tel);
                    cmd.Parameters.AddWithValue("@email", email);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir dados: " + ex.Message);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        private void busca()
        {
            banco bd = new banco();
            string sql;
            MySqlCommand cmd; ;

            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Funcionario.NOME AS Funcionario " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            //dataGridView1.DataSource = dataTable;
        }
    }




}

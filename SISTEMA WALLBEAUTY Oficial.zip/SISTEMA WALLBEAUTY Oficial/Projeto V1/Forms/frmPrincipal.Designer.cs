﻿namespace Projeto_V1
{
    partial class Principal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelLeftTop = new System.Windows.Forms.Panel();
            this.hora = new System.Windows.Forms.Label();
            this.data = new System.Windows.Forms.Label();
            this.relogioGif = new System.Windows.Forms.PictureBox();
            this.panelLeftModal = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.numAgendamentosCancelados = new System.Windows.Forms.Label();
            this.numAgendamentosCanceladosMes = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.numAgendamentosConcluidos = new System.Windows.Forms.Label();
            this.numAgendamentosConcluidosMes = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numAgendamentosMes = new System.Windows.Forms.Label();
            this.numAgendamentos = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panelDropDown = new System.Windows.Forms.Panel();
            this.btAgendaAgendamento = new System.Windows.Forms.Button();
            this.btAgendaEditar = new System.Windows.Forms.Button();
            this.btAgenda = new System.Windows.Forms.Button();
            this.panelResumo = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panelDropDown2 = new System.Windows.Forms.Panel();
            this.btFuncionarioCadastro = new System.Windows.Forms.Button();
            this.btFuncionarioEditar = new System.Windows.Forms.Button();
            this.btFuncionario = new System.Windows.Forms.Button();
            this.panelDropDown3 = new System.Windows.Forms.Panel();
            this.btClienteCadastro = new System.Windows.Forms.Button();
            this.btClienteEditar = new System.Windows.Forms.Button();
            this.btCliente = new System.Windows.Forms.Button();
            this.panelDropDown4 = new System.Windows.Forms.Panel();
            this.btServicoCadastro = new System.Windows.Forms.Button();
            this.btServicoEditar = new System.Windows.Forms.Button();
            this.btServicos = new System.Windows.Forms.Button();
            this.timerRelogio = new System.Windows.Forms.Timer(this.components);
            this.timerAgenda = new System.Windows.Forms.Timer(this.components);
            this.timerFuncionarios = new System.Windows.Forms.Timer(this.components);
            this.timerClientes = new System.Windows.Forms.Timer(this.components);
            this.timerServicos = new System.Windows.Forms.Timer(this.components);
            this.panelAgenda = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.LOGOUT = new System.Windows.Forms.Button();
            this.nomeFuncionarioLogin = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelUsuario = new System.Windows.Forms.Label();
            this.panelLeftTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.relogioGif)).BeginInit();
            this.panelLeftModal.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelDropDown.SuspendLayout();
            this.panelResumo.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panelDropDown2.SuspendLayout();
            this.panelDropDown3.SuspendLayout();
            this.panelDropDown4.SuspendLayout();
            this.panelAgenda.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLeftTop
            // 
            this.panelLeftTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelLeftTop.Controls.Add(this.hora);
            this.panelLeftTop.Controls.Add(this.data);
            this.panelLeftTop.Controls.Add(this.relogioGif);
            this.panelLeftTop.Location = new System.Drawing.Point(0, 0);
            this.panelLeftTop.Name = "panelLeftTop";
            this.panelLeftTop.Size = new System.Drawing.Size(202, 69);
            this.panelLeftTop.TabIndex = 1;
            // 
            // hora
            // 
            this.hora.AutoSize = true;
            this.hora.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hora.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hora.Location = new System.Drawing.Point(70, 35);
            this.hora.Name = "hora";
            this.hora.Size = new System.Drawing.Size(51, 24);
            this.hora.TabIndex = 3;
            this.hora.Text = "Hora";
            // 
            // data
            // 
            this.data.AutoSize = true;
            this.data.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.data.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.data.Location = new System.Drawing.Point(70, 13);
            this.data.Name = "data";
            this.data.Size = new System.Drawing.Size(47, 24);
            this.data.TabIndex = 3;
            this.data.Text = "Data";
            // 
            // relogioGif
            // 
            this.relogioGif.BackgroundImage = global::Projeto_V1.Properties.Resources.White_Clock;
            this.relogioGif.Image = global::Projeto_V1.Properties.Resources.White_Clock;
            this.relogioGif.Location = new System.Drawing.Point(11, 8);
            this.relogioGif.Name = "relogioGif";
            this.relogioGif.Size = new System.Drawing.Size(52, 54);
            this.relogioGif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.relogioGif.TabIndex = 3;
            this.relogioGif.TabStop = false;
            // 
            // panelLeftModal
            // 
            this.panelLeftModal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panelLeftModal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panelLeftModal.Controls.Add(this.panel3);
            this.panelLeftModal.Controls.Add(this.panel2);
            this.panelLeftModal.Controls.Add(this.panel1);
            this.panelLeftModal.Controls.Add(this.panelDropDown);
            this.panelLeftModal.Controls.Add(this.panelResumo);
            this.panelLeftModal.Controls.Add(this.panelDropDown2);
            this.panelLeftModal.Controls.Add(this.panelDropDown3);
            this.panelLeftModal.Controls.Add(this.panelDropDown4);
            this.panelLeftModal.Location = new System.Drawing.Point(0, 69);
            this.panelLeftModal.Name = "panelLeftModal";
            this.panelLeftModal.Size = new System.Drawing.Size(202, 659);
            this.panelLeftModal.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.numAgendamentosCancelados);
            this.panel3.Controls.Add(this.numAgendamentosCanceladosMes);
            this.panel3.Location = new System.Drawing.Point(0, 472);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(201, 78);
            this.panel3.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label8.Location = new System.Drawing.Point(40, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 24);
            this.label8.TabIndex = 13;
            this.label8.Text = "Dia";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label4.Location = new System.Drawing.Point(48, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 24);
            this.label4.TabIndex = 2;
            this.label4.Text = "Cancelados";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label9.Location = new System.Drawing.Point(119, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 24);
            this.label9.TabIndex = 10;
            this.label9.Text = "Mês";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numAgendamentosCancelados
            // 
            this.numAgendamentosCancelados.AutoSize = true;
            this.numAgendamentosCancelados.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentosCancelados.ForeColor = System.Drawing.Color.Red;
            this.numAgendamentosCancelados.Location = new System.Drawing.Point(43, 44);
            this.numAgendamentosCancelados.Name = "numAgendamentosCancelados";
            this.numAgendamentosCancelados.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentosCancelados.TabIndex = 12;
            this.numAgendamentosCancelados.Text = "50";
            // 
            // numAgendamentosCanceladosMes
            // 
            this.numAgendamentosCanceladosMes.AutoSize = true;
            this.numAgendamentosCanceladosMes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentosCanceladosMes.ForeColor = System.Drawing.Color.Red;
            this.numAgendamentosCanceladosMes.Location = new System.Drawing.Point(129, 44);
            this.numAgendamentosCanceladosMes.Name = "numAgendamentosCanceladosMes";
            this.numAgendamentosCanceladosMes.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentosCanceladosMes.TabIndex = 11;
            this.numAgendamentosCanceladosMes.Text = "50";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.numAgendamentosConcluidos);
            this.panel2.Controls.Add(this.numAgendamentosConcluidosMes);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(0, 396);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 77);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label1.Location = new System.Drawing.Point(50, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Concluidos";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numAgendamentosConcluidos
            // 
            this.numAgendamentosConcluidos.AutoSize = true;
            this.numAgendamentosConcluidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentosConcluidos.ForeColor = System.Drawing.Color.Lime;
            this.numAgendamentosConcluidos.Location = new System.Drawing.Point(43, 43);
            this.numAgendamentosConcluidos.Name = "numAgendamentosConcluidos";
            this.numAgendamentosConcluidos.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentosConcluidos.TabIndex = 4;
            this.numAgendamentosConcluidos.Text = "50";
            this.numAgendamentosConcluidos.Click += new System.EventHandler(this.numAgendamentos_Click);
            // 
            // numAgendamentosConcluidosMes
            // 
            this.numAgendamentosConcluidosMes.AutoSize = true;
            this.numAgendamentosConcluidosMes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentosConcluidosMes.ForeColor = System.Drawing.Color.Lime;
            this.numAgendamentosConcluidosMes.Location = new System.Drawing.Point(129, 43);
            this.numAgendamentosConcluidosMes.Name = "numAgendamentosConcluidosMes";
            this.numAgendamentosConcluidosMes.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentosConcluidosMes.TabIndex = 4;
            this.numAgendamentosConcluidosMes.Text = "50";
            this.numAgendamentosConcluidosMes.Click += new System.EventHandler(this.numAgendamentos_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label10.Location = new System.Drawing.Point(119, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "Mês";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label11.Location = new System.Drawing.Point(38, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 24);
            this.label11.TabIndex = 8;
            this.label11.Text = "Dia";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.numAgendamentosMes);
            this.panel1.Controls.Add(this.numAgendamentos);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(1, 320);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(201, 76);
            this.panel1.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label6.Location = new System.Drawing.Point(39, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 24);
            this.label6.TabIndex = 13;
            this.label6.Text = "Dia";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label7.Location = new System.Drawing.Point(118, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 24);
            this.label7.TabIndex = 10;
            this.label7.Text = "Mês";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numAgendamentosMes
            // 
            this.numAgendamentosMes.AutoSize = true;
            this.numAgendamentosMes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentosMes.ForeColor = System.Drawing.Color.Blue;
            this.numAgendamentosMes.Location = new System.Drawing.Point(128, 49);
            this.numAgendamentosMes.Name = "numAgendamentosMes";
            this.numAgendamentosMes.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentosMes.TabIndex = 11;
            this.numAgendamentosMes.Text = "50";
            this.numAgendamentosMes.Click += new System.EventHandler(this.numAgendamentosMes_Click);
            // 
            // numAgendamentos
            // 
            this.numAgendamentos.AutoSize = true;
            this.numAgendamentos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.numAgendamentos.ForeColor = System.Drawing.Color.Blue;
            this.numAgendamentos.Location = new System.Drawing.Point(42, 49);
            this.numAgendamentos.Name = "numAgendamentos";
            this.numAgendamentos.Size = new System.Drawing.Size(30, 24);
            this.numAgendamentos.TabIndex = 12;
            this.numAgendamentos.Text = "50";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label3.Location = new System.Drawing.Point(46, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "Agendados";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelDropDown
            // 
            this.panelDropDown.BackColor = System.Drawing.Color.Transparent;
            this.panelDropDown.Controls.Add(this.btAgendaAgendamento);
            this.panelDropDown.Controls.Add(this.btAgendaEditar);
            this.panelDropDown.Controls.Add(this.btAgenda);
            this.panelDropDown.Location = new System.Drawing.Point(0, 0);
            this.panelDropDown.MaximumSize = new System.Drawing.Size(202, 142);
            this.panelDropDown.MinimumSize = new System.Drawing.Size(202, 60);
            this.panelDropDown.Name = "panelDropDown";
            this.panelDropDown.Size = new System.Drawing.Size(202, 60);
            this.panelDropDown.TabIndex = 11;
            // 
            // btAgendaAgendamento
            // 
            this.btAgendaAgendamento.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btAgendaAgendamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.btAgendaAgendamento.FlatAppearance.BorderSize = 0;
            this.btAgendaAgendamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAgendaAgendamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAgendaAgendamento.Location = new System.Drawing.Point(0, 101);
            this.btAgendaAgendamento.Name = "btAgendaAgendamento";
            this.btAgendaAgendamento.Size = new System.Drawing.Size(202, 41);
            this.btAgendaAgendamento.TabIndex = 2;
            this.btAgendaAgendamento.Text = "Agendamento";
            this.btAgendaAgendamento.UseVisualStyleBackColor = false;
            this.btAgendaAgendamento.Click += new System.EventHandler(this.btAgendaAgendamento_Click);
            // 
            // btAgendaEditar
            // 
            this.btAgendaEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btAgendaEditar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btAgendaEditar.FlatAppearance.BorderSize = 0;
            this.btAgendaEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAgendaEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAgendaEditar.Location = new System.Drawing.Point(0, 60);
            this.btAgendaEditar.Name = "btAgendaEditar";
            this.btAgendaEditar.Size = new System.Drawing.Size(202, 41);
            this.btAgendaEditar.TabIndex = 1;
            this.btAgendaEditar.Text = "Editar";
            this.btAgendaEditar.UseVisualStyleBackColor = false;
            this.btAgendaEditar.Click += new System.EventHandler(this.btAgendaEditar_Click);
            // 
            // btAgenda
            // 
            this.btAgenda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.btAgenda.Dock = System.Windows.Forms.DockStyle.Top;
            this.btAgenda.FlatAppearance.BorderSize = 0;
            this.btAgenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAgenda.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAgenda.Image = global::Projeto_V1.Properties.Resources.Expand_Arrow_20px;
            this.btAgenda.Location = new System.Drawing.Point(0, 0);
            this.btAgenda.MaximumSize = new System.Drawing.Size(202, 227);
            this.btAgenda.MinimumSize = new System.Drawing.Size(202, 60);
            this.btAgenda.Name = "btAgenda";
            this.btAgenda.Size = new System.Drawing.Size(202, 60);
            this.btAgenda.TabIndex = 0;
            this.btAgenda.Text = "Agenda";
            this.btAgenda.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btAgenda.UseVisualStyleBackColor = false;
            this.btAgenda.Click += new System.EventHandler(this.btAgenda_Click_1);
            // 
            // panelResumo
            // 
            this.panelResumo.BackColor = System.Drawing.Color.Silver;
            this.panelResumo.Controls.Add(this.panel4);
            this.panelResumo.Location = new System.Drawing.Point(1, 321);
            this.panelResumo.Name = "panelResumo";
            this.panelResumo.Size = new System.Drawing.Size(201, 338);
            this.panelResumo.TabIndex = 15;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panel4.Controls.Add(this.button1);
            this.panel4.Location = new System.Drawing.Point(-1, 229);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(201, 109);
            this.panel4.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(54, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 26);
            this.button1.TabIndex = 3;
            this.button1.Text = "Atualizar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panelDropDown2
            // 
            this.panelDropDown2.BackColor = System.Drawing.Color.Transparent;
            this.panelDropDown2.Controls.Add(this.btFuncionarioCadastro);
            this.panelDropDown2.Controls.Add(this.btFuncionarioEditar);
            this.panelDropDown2.Controls.Add(this.btFuncionario);
            this.panelDropDown2.Location = new System.Drawing.Point(0, 60);
            this.panelDropDown2.MaximumSize = new System.Drawing.Size(202, 142);
            this.panelDropDown2.MinimumSize = new System.Drawing.Size(202, 60);
            this.panelDropDown2.Name = "panelDropDown2";
            this.panelDropDown2.Size = new System.Drawing.Size(202, 60);
            this.panelDropDown2.TabIndex = 12;
            // 
            // btFuncionarioCadastro
            // 
            this.btFuncionarioCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btFuncionarioCadastro.Dock = System.Windows.Forms.DockStyle.Top;
            this.btFuncionarioCadastro.FlatAppearance.BorderSize = 0;
            this.btFuncionarioCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFuncionarioCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFuncionarioCadastro.Location = new System.Drawing.Point(0, 101);
            this.btFuncionarioCadastro.Name = "btFuncionarioCadastro";
            this.btFuncionarioCadastro.Size = new System.Drawing.Size(202, 41);
            this.btFuncionarioCadastro.TabIndex = 2;
            this.btFuncionarioCadastro.Text = "Cadastro";
            this.btFuncionarioCadastro.UseVisualStyleBackColor = false;
            this.btFuncionarioCadastro.Click += new System.EventHandler(this.btFuncionarioCadastro_Click);
            // 
            // btFuncionarioEditar
            // 
            this.btFuncionarioEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btFuncionarioEditar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btFuncionarioEditar.FlatAppearance.BorderSize = 0;
            this.btFuncionarioEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFuncionarioEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFuncionarioEditar.Location = new System.Drawing.Point(0, 60);
            this.btFuncionarioEditar.Name = "btFuncionarioEditar";
            this.btFuncionarioEditar.Size = new System.Drawing.Size(202, 41);
            this.btFuncionarioEditar.TabIndex = 1;
            this.btFuncionarioEditar.Text = "Editar";
            this.btFuncionarioEditar.UseVisualStyleBackColor = false;
            this.btFuncionarioEditar.Click += new System.EventHandler(this.btFuncionarioEditar_Click);
            // 
            // btFuncionario
            // 
            this.btFuncionario.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.btFuncionario.Dock = System.Windows.Forms.DockStyle.Top;
            this.btFuncionario.FlatAppearance.BorderSize = 0;
            this.btFuncionario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFuncionario.Image = global::Projeto_V1.Properties.Resources.Expand_Arrow_20px;
            this.btFuncionario.Location = new System.Drawing.Point(0, 0);
            this.btFuncionario.MaximumSize = new System.Drawing.Size(202, 227);
            this.btFuncionario.MinimumSize = new System.Drawing.Size(202, 60);
            this.btFuncionario.Name = "btFuncionario";
            this.btFuncionario.Size = new System.Drawing.Size(202, 60);
            this.btFuncionario.TabIndex = 0;
            this.btFuncionario.Text = "Funcionários";
            this.btFuncionario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btFuncionario.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btFuncionario.UseVisualStyleBackColor = false;
            this.btFuncionario.Click += new System.EventHandler(this.btFuncionario_Click_1);
            // 
            // panelDropDown3
            // 
            this.panelDropDown3.BackColor = System.Drawing.Color.Transparent;
            this.panelDropDown3.Controls.Add(this.btClienteCadastro);
            this.panelDropDown3.Controls.Add(this.btClienteEditar);
            this.panelDropDown3.Controls.Add(this.btCliente);
            this.panelDropDown3.Location = new System.Drawing.Point(0, 119);
            this.panelDropDown3.MaximumSize = new System.Drawing.Size(202, 142);
            this.panelDropDown3.MinimumSize = new System.Drawing.Size(202, 60);
            this.panelDropDown3.Name = "panelDropDown3";
            this.panelDropDown3.Size = new System.Drawing.Size(202, 60);
            this.panelDropDown3.TabIndex = 13;
            // 
            // btClienteCadastro
            // 
            this.btClienteCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btClienteCadastro.Dock = System.Windows.Forms.DockStyle.Top;
            this.btClienteCadastro.FlatAppearance.BorderSize = 0;
            this.btClienteCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btClienteCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClienteCadastro.Location = new System.Drawing.Point(0, 101);
            this.btClienteCadastro.Name = "btClienteCadastro";
            this.btClienteCadastro.Size = new System.Drawing.Size(202, 41);
            this.btClienteCadastro.TabIndex = 2;
            this.btClienteCadastro.Text = "Cadastro";
            this.btClienteCadastro.UseVisualStyleBackColor = false;
            this.btClienteCadastro.Click += new System.EventHandler(this.btClienteCadastro_Click);
            // 
            // btClienteEditar
            // 
            this.btClienteEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btClienteEditar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btClienteEditar.FlatAppearance.BorderSize = 0;
            this.btClienteEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btClienteEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btClienteEditar.Location = new System.Drawing.Point(0, 60);
            this.btClienteEditar.Name = "btClienteEditar";
            this.btClienteEditar.Size = new System.Drawing.Size(202, 41);
            this.btClienteEditar.TabIndex = 1;
            this.btClienteEditar.Text = "Editar";
            this.btClienteEditar.UseVisualStyleBackColor = false;
            this.btClienteEditar.Click += new System.EventHandler(this.btClienteEditar_Click);
            // 
            // btCliente
            // 
            this.btCliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.btCliente.Dock = System.Windows.Forms.DockStyle.Top;
            this.btCliente.FlatAppearance.BorderSize = 0;
            this.btCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCliente.Image = global::Projeto_V1.Properties.Resources.Expand_Arrow_20px;
            this.btCliente.Location = new System.Drawing.Point(0, 0);
            this.btCliente.MaximumSize = new System.Drawing.Size(202, 227);
            this.btCliente.MinimumSize = new System.Drawing.Size(202, 60);
            this.btCliente.Name = "btCliente";
            this.btCliente.Size = new System.Drawing.Size(202, 60);
            this.btCliente.TabIndex = 0;
            this.btCliente.Text = "Clientes";
            this.btCliente.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btCliente.UseVisualStyleBackColor = false;
            this.btCliente.Click += new System.EventHandler(this.btClientes_Click_1);
            // 
            // panelDropDown4
            // 
            this.panelDropDown4.BackColor = System.Drawing.Color.Transparent;
            this.panelDropDown4.Controls.Add(this.btServicoCadastro);
            this.panelDropDown4.Controls.Add(this.btServicoEditar);
            this.panelDropDown4.Controls.Add(this.btServicos);
            this.panelDropDown4.Location = new System.Drawing.Point(0, 179);
            this.panelDropDown4.MaximumSize = new System.Drawing.Size(202, 142);
            this.panelDropDown4.MinimumSize = new System.Drawing.Size(202, 60);
            this.panelDropDown4.Name = "panelDropDown4";
            this.panelDropDown4.Size = new System.Drawing.Size(202, 60);
            this.panelDropDown4.TabIndex = 14;
            // 
            // btServicoCadastro
            // 
            this.btServicoCadastro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btServicoCadastro.Dock = System.Windows.Forms.DockStyle.Top;
            this.btServicoCadastro.FlatAppearance.BorderSize = 0;
            this.btServicoCadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btServicoCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btServicoCadastro.Location = new System.Drawing.Point(0, 101);
            this.btServicoCadastro.Name = "btServicoCadastro";
            this.btServicoCadastro.Size = new System.Drawing.Size(202, 41);
            this.btServicoCadastro.TabIndex = 2;
            this.btServicoCadastro.Text = "Cadastro";
            this.btServicoCadastro.UseVisualStyleBackColor = false;
            this.btServicoCadastro.Click += new System.EventHandler(this.btServicoCadastro_Click);
            // 
            // btServicoEditar
            // 
            this.btServicoEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.btServicoEditar.Dock = System.Windows.Forms.DockStyle.Top;
            this.btServicoEditar.FlatAppearance.BorderSize = 0;
            this.btServicoEditar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btServicoEditar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btServicoEditar.Location = new System.Drawing.Point(0, 60);
            this.btServicoEditar.Name = "btServicoEditar";
            this.btServicoEditar.Size = new System.Drawing.Size(202, 41);
            this.btServicoEditar.TabIndex = 1;
            this.btServicoEditar.Text = "Editar";
            this.btServicoEditar.UseVisualStyleBackColor = false;
            this.btServicoEditar.Click += new System.EventHandler(this.btServicoEditar_Click);
            // 
            // btServicos
            // 
            this.btServicos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.btServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.btServicos.FlatAppearance.BorderSize = 0;
            this.btServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btServicos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btServicos.Image = global::Projeto_V1.Properties.Resources.Expand_Arrow_20px;
            this.btServicos.Location = new System.Drawing.Point(0, 0);
            this.btServicos.MaximumSize = new System.Drawing.Size(202, 227);
            this.btServicos.MinimumSize = new System.Drawing.Size(202, 60);
            this.btServicos.Name = "btServicos";
            this.btServicos.Size = new System.Drawing.Size(202, 60);
            this.btServicos.TabIndex = 0;
            this.btServicos.Text = "Serviços";
            this.btServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btServicos.UseVisualStyleBackColor = false;
            this.btServicos.Click += new System.EventHandler(this.btServicos_Click_1);
            // 
            // timerRelogio
            // 
            this.timerRelogio.Enabled = true;
            this.timerRelogio.Tick += new System.EventHandler(this.timerRelogio_Tick_1);
            // 
            // timerAgenda
            // 
            this.timerAgenda.Enabled = true;
            this.timerAgenda.Interval = 15;
            this.timerAgenda.Tick += new System.EventHandler(this.timerAgenda_Tick_1);
            // 
            // timerFuncionarios
            // 
            this.timerFuncionarios.Enabled = true;
            this.timerFuncionarios.Interval = 15;
            this.timerFuncionarios.Tick += new System.EventHandler(this.timerFuncionarios_Tick_1);
            // 
            // timerClientes
            // 
            this.timerClientes.Enabled = true;
            this.timerClientes.Interval = 15;
            this.timerClientes.Tick += new System.EventHandler(this.timerClientes_Tick_1);
            // 
            // timerServicos
            // 
            this.timerServicos.Enabled = true;
            this.timerServicos.Interval = 15;
            this.timerServicos.Tick += new System.EventHandler(this.timerServicos_Tick_1);
            // 
            // panelAgenda
            // 
            this.panelAgenda.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelAgenda.Controls.Add(this.pictureBox1);
            this.panelAgenda.Location = new System.Drawing.Point(202, 69);
            this.panelAgenda.MaximumSize = new System.Drawing.Size(1149, 659);
            this.panelAgenda.MinimumSize = new System.Drawing.Size(1149, 659);
            this.panelAgenda.Name = "panelAgenda";
            this.panelAgenda.Size = new System.Drawing.Size(1149, 659);
            this.panelAgenda.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Projeto_V1.Properties.Resources.back1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1149, 659);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // panelTop
            // 
            this.panelTop.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(199)))), ((int)(((byte)(217)))));
            this.panelTop.Controls.Add(this.LOGOUT);
            this.panelTop.Controls.Add(this.nomeFuncionarioLogin);
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.labelUsuario);
            this.panelTop.Location = new System.Drawing.Point(202, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1149, 69);
            this.panelTop.TabIndex = 4;
            // 
            // LOGOUT
            // 
            this.LOGOUT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOGOUT.Location = new System.Drawing.Point(1058, 18);
            this.LOGOUT.Name = "LOGOUT";
            this.LOGOUT.Size = new System.Drawing.Size(78, 28);
            this.LOGOUT.TabIndex = 5;
            this.LOGOUT.Text = "LOGOUT";
            this.LOGOUT.UseVisualStyleBackColor = true;
            this.LOGOUT.Click += new System.EventHandler(this.LOGOUT_Click);
            // 
            // nomeFuncionarioLogin
            // 
            this.nomeFuncionarioLogin.AutoSize = true;
            this.nomeFuncionarioLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.nomeFuncionarioLogin.Location = new System.Drawing.Point(79, 26);
            this.nomeFuncionarioLogin.Name = "nomeFuncionarioLogin";
            this.nomeFuncionarioLogin.Size = new System.Drawing.Size(0, 20);
            this.nomeFuncionarioLogin.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(315, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 2;
            // 
            // labelUsuario
            // 
            this.labelUsuario.AutoSize = true;
            this.labelUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUsuario.Location = new System.Drawing.Point(5, 26);
            this.labelUsuario.Name = "labelUsuario";
            this.labelUsuario.Size = new System.Drawing.Size(68, 20);
            this.labelUsuario.TabIndex = 1;
            this.labelUsuario.Text = "Usuário:";
            // 
            // Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelAgenda);
            this.Controls.Add(this.panelLeftModal);
            this.Controls.Add(this.panelLeftTop);
            this.MaximumSize = new System.Drawing.Size(1920, 1080);
            this.MinimumSize = new System.Drawing.Size(1366, 768);
            this.Name = "Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Walbeauty";
            this.Load += new System.EventHandler(this.Principal_Load);
            this.panelLeftTop.ResumeLayout(false);
            this.panelLeftTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.relogioGif)).EndInit();
            this.panelLeftModal.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelDropDown.ResumeLayout(false);
            this.panelResumo.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panelDropDown2.ResumeLayout(false);
            this.panelDropDown3.ResumeLayout(false);
            this.panelDropDown4.ResumeLayout(false);
            this.panelAgenda.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelLeftTop;
        private System.Windows.Forms.Panel panelLeftModal;
        private System.Windows.Forms.PictureBox relogioGif;
        private System.Windows.Forms.Label data;
        private System.Windows.Forms.Label hora;
        private System.Windows.Forms.Timer timerRelogio;
        private System.Windows.Forms.Panel panelDropDown;
        private System.Windows.Forms.Button btAgendaAgendamento;
        private System.Windows.Forms.Button btAgendaEditar;
        private System.Windows.Forms.Button btAgenda;
        private System.Windows.Forms.Panel panelDropDown2;
        private System.Windows.Forms.Button btFuncionarioCadastro;
        private System.Windows.Forms.Button btFuncionarioEditar;
        private System.Windows.Forms.Button btFuncionario;
        private System.Windows.Forms.Panel panelDropDown3;
        private System.Windows.Forms.Button btClienteCadastro;
        private System.Windows.Forms.Button btClienteEditar;
        private System.Windows.Forms.Button btCliente;
        private System.Windows.Forms.Panel panelDropDown4;
        private System.Windows.Forms.Button btServicoCadastro;
        private System.Windows.Forms.Button btServicoEditar;
        private System.Windows.Forms.Button btServicos;
        private System.Windows.Forms.Timer timerAgenda;
        private System.Windows.Forms.Timer timerFuncionarios;
        private System.Windows.Forms.Timer timerClientes;
        private System.Windows.Forms.Timer timerServicos;
        private System.Windows.Forms.Panel panelAgenda;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelUsuario;
        private System.Windows.Forms.Panel panelResumo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label nomeFuncionarioLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label numAgendamentosMes;
        private System.Windows.Forms.Label numAgendamentos;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label numAgendamentosCanceladosMes;
        private System.Windows.Forms.Label numAgendamentosCancelados;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label numAgendamentosConcluidosMes;
        private System.Windows.Forms.Label numAgendamentosConcluidos;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button LOGOUT;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button1;
    }
}


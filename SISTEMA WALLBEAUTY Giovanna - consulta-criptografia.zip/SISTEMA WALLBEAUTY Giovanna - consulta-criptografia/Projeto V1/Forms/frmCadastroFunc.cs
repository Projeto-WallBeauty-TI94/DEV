﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Projeto_V1.Forms
{
    public partial class frmCadastroFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string Id;
        public frmCadastroFunc()
        {
            InitializeComponent();
        }

        

        private void btnInsert_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            if (string.IsNullOrEmpty(tbNome.Text) || string.IsNullOrEmpty(tbSobrenome.Text))
            {
                MessageBox.Show("Insira dados válidos.");
            }
            else
            {
                string senhaCriptografada = CriptografarSenha(tbSenha.Text); // Criptografar a senha antes de enviar ao banco de dados

                string sql = "INSERT INTO funcionario (NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,SENHA,DATA_NASCIMENTO,DATA_CONTRATACAO) VALUES (@nome, @sobrenome, @cpf, @email, @telefone, @cep, @salario, @senha, @data_nascimento, @data_contratacao)";
                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                cmd.Parameters.AddWithValue("@senha", senhaCriptografada); // Usar a senha criptografada
                cmd.Parameters.AddWithValue("@data_nascimento", dateNascimento.Value);
                cmd.Parameters.AddWithValue("@data_contratacao", dateAdmissao.Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Dados inseridos");
            }
            bd.fecharConn();
        }

        // Função para criptografar a senha usando SHA256
        private string CriptografarSenha(string senha)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Converter a senha para um array de bytes
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha));

                // Converter os bytes para uma string hexadecimal
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void tbSenha_KeyPress(object sender, KeyPressEventArgs e)
        {

                // Verifica se o caractere digitado não é uma tecla de controle (como Backspace)
                if (!char.IsControl(e.KeyChar))
                {
                    // Substitui o caractere digitado por um asterisco
                    tbSenha.PasswordChar = '*';
                }
                else
                {
                    // Permite a digitação de teclas de controle, como Backspace
                    tbSenha.PasswordChar = '\0';
                }

        }
    }
}

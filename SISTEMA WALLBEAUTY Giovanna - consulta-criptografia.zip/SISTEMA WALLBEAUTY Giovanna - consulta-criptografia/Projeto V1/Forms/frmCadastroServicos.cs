﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmCadastroServicos : Form
    {

        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string Id;
        public frmCadastroServicos()
        {
            InitializeComponent();
        }

        private void btCadastrar_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            if ((tbNome.Text == "") && (tbPreco.Text == ""))
            {
                MessageBox.Show("Insira dados válidos.");
            }
            else
            {
                sql = "insert into servico (NOME,DESCRICAO,PRECO)values(@nome,@descricao,@preco)"; //os '@' identifica que são parâmetros
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                cmd.Parameters.AddWithValue("@descricao", tbDesc.Text);
                cmd.Parameters.AddWithValue("@preco", tbPreco.Text);
                
                cmd.ExecuteNonQuery();
                MessageBox.Show("Dados inseridos");

            }
            bd.fecharConn();
        }

        private void frmCadastroServicos_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

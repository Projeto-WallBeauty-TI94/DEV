﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConexãoComClasse
{
    public partial class Form1 : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string id;
        public Form1()
        {
            InitializeComponent();
        }

        private void formataDG()
        {
            //dataGridView1.Columns[0].HeaderText = "Código";
            //dataGridView1.Columns[0].Visible = false; Ocultar esta célula
            //dataGridView1.Columns[1].HeaderText = "E-mail";
            dataGridView1.Columns[1].HeaderText = "Nome";
            //dataGridView1.Columns[3].HeaderText = "Sobrenome";
            dataGridView1.Columns[2].HeaderText = "CPF";
            //dataGridView1.Columns[5].HeaderText = "Data de Nascimento";
            //dataGridView1.Columns[6].HeaderText = "Idade";
            //dataGridView1.Columns[7].HeaderText = "País de Orígem";
            //dataGridView1.Columns[8].HeaderText = "Endereço";
            //dataGridView1.Columns[9].HeaderText = "Telefone";
            //dataGridView1.Columns[10].HeaderText = "Senha";
        }

        private void listar()
        {
            bd.abrirConn();
            sql = "Select * from usuario order by nome asc";
            cmd = new MySqlCommand(sql,bd.conn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand= cmd;
            DataTable dataTable= new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource= dataTable;
        }


        private void btnInsert_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            if((dbName.Text == "")&&(dbCPF.Text == ""))
            {
                MessageBox.Show("Insira dados válidos.");
            }
            else 
            {
                sql = "insert into usuario (nome,cpf)values(@nome,@cpf)"; //os '@' identifica que são parâmetros
                cmd = new MySqlCommand(sql, bd.conn);
                cmd.Parameters.AddWithValue("@nome", dbName.Text);
                cmd.Parameters.AddWithValue("@cpf", dbCPF.Text);
                cmd.ExecuteNonQuery();
                listar();
                MessageBox.Show("Dados inseridos");
            }
            bd.fecharConn();

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            listar();
            formataDG();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);
            
            if (dialogResult == DialogResult.Yes)
            { 
                bd.abrirConn();
                sql = "Delete from usuario where id=@cod";
                cmd = new MySqlCommand(sql, bd.conn);
                cmd.Parameters.AddWithValue("@cod", id);
                cmd.ExecuteNonQuery();
                listar();
                MessageBox.Show("Dados deletados!");
            }

            bd.fecharConn();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            label3.Text = id;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if((textBox1.Text == "")&&(textBox2.Text == ""))
            {
                MessageBox.Show("Insira dados válidos.");
            }
            bd.abrirConn();
            sql = "update usuario set nome=@nome, cpf=@cpf where id=@id";
            cmd = new MySqlCommand(sql, bd.conn);
            cmd.Parameters.AddWithValue("@nome", textBox1.Text);
            cmd.Parameters.AddWithValue("@cpf", textBox2.Text);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "select id from usuario";
            cmd = new MySqlCommand(sql, bd.conn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "id";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string select = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            label5.Text = select;
        }

        private void rbNome_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNome.Checked)
            {
                tbNome.Visible = true;
                tbCpf.Visible = false;
            }
        }

        private void rbCpf_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNome.Checked)
            {
                tbNome.Visible = false;
                tbCpf.Visible = true;
            }
        }
    }
}

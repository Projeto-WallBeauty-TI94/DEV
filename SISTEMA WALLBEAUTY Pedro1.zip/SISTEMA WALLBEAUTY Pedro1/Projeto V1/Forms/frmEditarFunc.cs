﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string id;

        public object Id { get; private set; }

        public frmEditarFunc()
        {
            InitializeComponent();
            tbSenha.PasswordChar = '*';
        }

        private int idFuncionario;





        private void listar()
        {
            bd.abrirConn();
            sql = "Select ID, NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,DATA_NASCIMENTO,DATA_CONTRATACAO from funcionario order by nome asc";
            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            // Verifica se o ID do funcionário é válido
            
                DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    try
                    {
                        bd.abrirConn();
                        string sql = "DELETE FROM funcionario WHERE id = @cod";
                        MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                        cmd.Parameters.AddWithValue("@cod", tbId.Text);
                        cmd.ExecuteNonQuery();
                        bd.fecharConn();

                        MessageBox.Show("Dados excluídos com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao excluir dados: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Operação cancelada.");
                }
            }
            
        


        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            // Verifica se o campo de ID não está vazio
            if (!string.IsNullOrEmpty(tbId.Text))
            {
                try
                {
                    // Converta o ID do texto para um número inteiro
                    if (int.TryParse(tbId.Text, out int id))
                    {
                        bd.abrirConn();

                        // Criptografar a senha usando SHA256
                        string senhaCriptografada = CriptografarSenha(tbSenha.Text);

                        string sql = "UPDATE funcionario SET nome=@nome, sobrenome=@sobrenome, cpf=@cpf, email=@email, telefone=@telefone, cep=@cep, senha=@senha, salario=@salario WHERE ID=@id";
                        MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                        cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                        cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                        cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                        cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                        cmd.Parameters.AddWithValue("@senha", senhaCriptografada); // Use a senha criptografada
                        cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                        cmd.ExecuteNonQuery();
                        bd.fecharConn();
                        MessageBox.Show("Funcionário atualizado com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira um ID válido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar funcionário: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o ID do funcionário que deseja atualizar.");
            }
        }

        private string CriptografarSenha(string senha)
        {
            using (SHA256 sha256 = SHA256Managed.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(senha);
                byte[] hash = sha256.ComputeHash(bytes);
                return BitConverter.ToString(hash).Replace("-", "").ToLower();
            }
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica se o clique foi em uma célula válida
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extrai os valores das células e os coloca nos TextBox correspondentes
                tbId.Text = row.Cells["id"].Value.ToString();
                tbNome.Text = row.Cells["nome"].Value.ToString();
                tbSobrenome.Text = row.Cells["sobrenome"].Value.ToString();
                tbCpf.Text = row.Cells["cpf"].Value.ToString();
                tbEmail.Text = row.Cells["email"].Value.ToString();
                tbTelefone.Text = row.Cells["telefone"].Value.ToString();
                tbCep.Text = row.Cells["cep"].Value.ToString();
                tbSalario.Text = row.Cells["salario"].Value.ToString();
                // Adicione mais TextBox conforme necessário para as colunas adicionais
            }
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {

        }

        private void btnConsulta_Click_1(object sender, EventArgs e)
        {
            listar();
        }

        private void frmEditarFunc_Load(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }


        // Evento TextChanged do TextBox nome
      

        private void tbId_TextChanged(object sender, EventArgs e)
        {
            // Atualiza o valor do ID sempre que o texto no tbId for alterado
            // Verifica se o texto pode ser convertido para um número inteiro
            if (int.TryParse(tbId.Text, out int id))
            {
                // Se a conversão for bem-sucedida, atualiza o valor do ID
                idFuncionario = id;
            }
            else
            {
                // Se a conversão falhar, define o ID como 0 ou outra ação apropriada
                idFuncionario = 0;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btnFechar_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbId_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}

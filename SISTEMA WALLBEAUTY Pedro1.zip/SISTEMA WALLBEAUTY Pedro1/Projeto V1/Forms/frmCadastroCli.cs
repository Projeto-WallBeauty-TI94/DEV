﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Projeto_V1.Forms
{
    public partial class frmCadastroCli : Form
    {

        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;

        public frmCadastroCli()
        {
            InitializeComponent();
        }

        private void LimparCampos()
        {
            tbNome.Text = "";
            tbCpf.Text = "";
            tbTel.Text = "";
            tbEmail.Text = "";
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            Funcoes.InserirCliente(tbNome.Text, tbCpf.Text, tbTel.Text, tbEmail.Text);
            LimparCampos();
            
        }

        private void frmEditarCli_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    
}

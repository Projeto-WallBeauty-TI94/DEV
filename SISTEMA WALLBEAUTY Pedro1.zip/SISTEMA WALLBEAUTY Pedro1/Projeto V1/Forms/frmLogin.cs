﻿using MySqlConnector;
using Projeto_V1;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmLogin : Form
    {

        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd;
        public frmLogin()
        {
            InitializeComponent();
            tbSenha.PasswordChar = '*';
        }



        private void button1_Click(object sender, EventArgs e)
        {
            // Abrir a conexão com o banco de dados
            bd.abrirConn();

            // Criptografar a senha digitada pelo usuário
            string senhaCriptografada = CriptografarSenha(tbSenha.Text);

            // Criar a consulta SQL para verificar o usuário e senha
            MySqlCommand query = new MySqlCommand("SELECT COUNT(*) FROM funcionario WHERE email = @email AND senha = @senha", bd.conecta);
            query.Parameters.AddWithValue("@email", tbEmail.Text);
            query.Parameters.AddWithValue("@senha", senhaCriptografada); // Usar a senha criptografada

            DataTable dataTable = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(query);
            da.Fill(dataTable);

            foreach (DataRow list in dataTable.Rows)
            {
                if (Convert.ToInt32(list.ItemArray[0]) > 0)
                {
                    MessageBox.Show("Usuário Logado com sucesso", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Principal principal = new Principal();
                    this.Close();
                    principal.Show();
                }
                else
                {
                    MessageBox.Show("Usuário Inválido", "Validação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            bd.fecharConn();
        }

        // Função para criptografar a senha usando SHA256 (ou o método que você usou)
        private string CriptografarSenha(string senha)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Converter a senha para um array de bytes
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha));

                // Converter os bytes para uma string hexadecimal
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }







        private void frmLogin_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

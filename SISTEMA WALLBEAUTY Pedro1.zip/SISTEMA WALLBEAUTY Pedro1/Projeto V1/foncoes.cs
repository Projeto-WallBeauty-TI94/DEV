﻿using MySqlConnector;
using Projeto_V1.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1
{



    public class Funcoes
    {
        public static void InserirCliente(string nome, string cpf, string tel, string email)
        {

            banco bd = new banco();
            string sql;

            try
            {
                bd.abrirConn();

                if (string.IsNullOrWhiteSpace(nome) && string.IsNullOrWhiteSpace(cpf))
                {
                    MessageBox.Show("Insira dados válidos.");
                }
                else
                {
                    sql = "insert into cliente (nome, cpf, tel, email) values(@nome, @cpf, @tel, @email)";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@tel", tel);
                    cmd.Parameters.AddWithValue("@email", email);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir dados: " + ex.Message);
            }
            finally
            {
                bd.fecharConn();
            }
        }
    }




}

﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarAgenda : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;

        public frmEditarAgenda()
        {
            InitializeComponent();
            busca();

        }

        //------------------------------------------------------------funções---------------------------------------------------------
        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Funcionario.NOME AS Funcionário, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }

        private void FillCliente()
        {
            bd.abrirConn();
            sql = "select nome from cliente";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbCliente.DataSource = dt;
                cbCliente.DisplayMember = "nome";                
            }

        }


        

        //-----------------------------------------------------crud do form----------------------------------------------------------

        //buscar
        private void btnSelect_Click_1(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.Id as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Funcionario.NOME AS Funcionário, Servico.PRECO as Preço " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id " +
                  "WHERE cliente.NOME = @BuscaCliente";

            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@BuscaCliente", cbBusca.Text);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;

        }


        //atualizar dados
        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja alterar as informações do agendamento?", "Dados atualizados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();

                sql = @"UPDATE agendamento
        SET agendamento.FUNCIONARIO_ID = (SELECT f.ID FROM funcionario f WHERE f.nome = @Func),
            agendamento.FK_CLIENTE_ID = (SELECT c.ID FROM cliente c WHERE c.nome = @Cliente),
            agendamento.FK_SERVICO_ID = (SELECT s.ID FROM servico s WHERE s.nome = @Serv),           
            agendamento.DATA_AGENDAMENTO = @DataAgenda,
            agendamento.HORA_AGENDAMENTO = @HoraAgenda            
        WHERE agendamento.ID = @Id";

                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
                cmd.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
                cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Value);
                cmd.Parameters.AddWithValue("@HoraAgenda", dtHora.Value);
                cmd.Parameters.AddWithValue("@Id", lbId.Text);
                cmd.ExecuteNonQuery();

                busca();

            }

        }


        //deletar
        private void btnCancel_Click_1(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja cancelar o serviço?", "Serviço cancelado.", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes && lbStatus.Text == "Concluído")
            {
                MessageBox.Show("O serviço selecionado já foi concluído.");
            }
                else
            {
                bd.abrirConn();
                sql = "update agendamento set STATUS= 'Cancelado' where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lbId.Text);
                cmd.ExecuteNonQuery();                
                busca();
            }
        }

        //reseta o datagridview, voltando a mostrar todos os agendamentos (caso tenha apertado o "buscar" e queira voltar atrás)
        private void btnReset_Click_1(object sender, EventArgs e)
        {
            busca();

        }

      


        

        private void dtBusca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnSelect.PerformClick();
            }
        }

        private void frmEditarAgenda_Load(object sender, EventArgs e)
        {

            

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.SelectedRows[0];

            string id = row.Cells["ID"].Value.ToString();
            lbId.Text = id;

            string status = row.Cells["status"].Value.ToString();
            lbStatus.Text = status;

            string data = row.Cells["Data"].Value.ToString();
            dtAgendamento.Enabled = true;
            dtAgendamento.Value = DateTime.Parse(data);

            string hora = row.Cells["Hora"].Value.ToString();
            dtHora.Enabled = true;
            dtHora.Value = DateTime.Today.Add(TimeSpan.Parse(hora));

            // Limpa os itens dos ComboBoxes antes de preenchê-los novamente


            // Preenche os ComboBoxes com dados do banco de dados
            FillServico();
            FillFuncionario();
            FillCliente();

            // Seleciona os itens nos ComboBoxes com base nos dados da linha selecionada
            string servico = row.Cells["SERVIÇO"].Value.ToString();
            cbServico.Enabled = true;
            int indexServico = cbServico.FindStringExact(servico);
            cbServico.SelectedIndex = indexServico;

            string funcionario = row.Cells["FUNCIONÁRIO"].Value.ToString();
            cbFunc.Enabled = true;
            int indexFuncionario = cbFunc.FindStringExact(funcionario);
            cbFunc.SelectedIndex = indexFuncionario;

            string cliente = row.Cells["CLIENTE"].Value.ToString();
            cbCliente.Enabled = true;
            int indexCliente = cbCliente.FindStringExact(cliente);
            cbCliente.SelectedIndex = indexCliente;

            string valor = row.Cells["PREÇO"].Value.ToString();
            tbValor.Text = valor;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void tbValor_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
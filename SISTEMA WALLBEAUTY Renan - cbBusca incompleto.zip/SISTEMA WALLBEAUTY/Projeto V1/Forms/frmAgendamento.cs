﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmAgendamento : Form
    {
        banco bd = new banco();
        Funcoes funcoes = new Funcoes();
        string sql;
        MySqlCommand cmd;
        string Id;

        public frmAgendamento()
        {
            InitializeComponent();
            busca();
            FillCliente();
            FillServico();
            FillFuncionario();

        }
        //------------------------------------------------------------funções---------------------------------------------------------


        private void PreencherComboBoxes()
        {
            
            DataTable clientes = funcoes.FillCliente();
            if (clientes != null && clientes.Rows.Count > 0)
            {
                cbCliente.DataSource = clientes.Copy(); // Preenche o cbCliente
                cbCliente.DisplayMember = "nome";

                cbBusca.DataSource = clientes.Copy(); // Preenche o cbBusca
                cbBusca.DisplayMember = "nome";
            }
        }
        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Funcionario.NOME AS Funcionário, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void FillCliente()
        {
            bd.abrirConn();
            sql = "select nome from cliente";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbCliente.DataSource = dt;
                cbCliente.DisplayMember = "nome";
            }

        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }
        //botão de criar agendamento
        private void btnInsert_Click(object sender, EventArgs e)
        {
            bd.abrirConn();
            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja agendar um serviço?", "Serviço agendado!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                sql = @"INSERT INTO `agendamento`(`FUNCIONARIO_ID`, `FK_CLIENTE_ID`, `FK_SERVICO_ID`, `DATA_AGENDAMENTO`, `HORA_AGENDAMENTO`) 
                SELECT f.ID AS FUNCIONARIO_ID, c.ID AS FK_CLIENTE_ID, s.ID AS FK_SERVICO_ID, @DataAgenda, @HoraAgenda
                FROM funcionario f
                INNER JOIN cliente c ON c.ID = (SELECT ID FROM cliente WHERE nome = @Cliente)
                INNER JOIN servico s ON s.ID = (SELECT ID FROM servico WHERE nome = @Serv)
                WHERE f.ID = (SELECT ID FROM funcionario WHERE nome = @Func)";

                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
                cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
                cmd.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Value);
                cmd.Parameters.AddWithValue("@HoraAgenda", cbHora.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Agendamento adicionado com sucesso!");
                busca();
            }

        }

        



        private void dtAgendamento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnInsert.PerformClick();
            }
        }

        private void dtHora_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnInsert.PerformClick();
            }
        }

        private void cbFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnInsert.PerformClick();
            }
        }

        private void cbCliente_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnInsert.PerformClick();
            }
        }

        private void cbServico_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnInsert.PerformClick();
            }
        }

        private void frmAgendamento_Load(object sender, EventArgs e)
        {

        }










        //------------------------------------------parte inútil só para o form não bugar--------------------------------------------




    }
}




﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmAgendamento : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;

        public frmAgendamento()
        {
            InitializeComponent();
            busca();
            FillCliente();
            FillServico();
            FillFuncionario();

        }
        //------------------------------------------------------------funções---------------------------------------------------------



        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Funcionario.NOME AS Funcionário, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }

        private void FillCliente()
        {
            bd.abrirConn();
            sql = "select nome from cliente";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbCliente.DataSource = dt;
                cbCliente.DisplayMember = "nome";
            }

        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome, preco from servico"; // Adiciona o preço à consulta SQL
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }


        //botão de criar agendamento
        private void btnInsert_Click(object sender, EventArgs e)
        {

        }

        private bool AgendamentoExistente()
        {
            string sqlVerificar = @"
        SELECT COUNT(*) 
        FROM agendamento 
        WHERE FUNCIONARIO_ID = (SELECT ID FROM funcionario WHERE nome = @Funcionario) 
        AND FK_CLIENTE_ID = (SELECT ID FROM cliente WHERE nome = @Cliente) 
        AND FK_SERVICO_ID = (SELECT ID FROM servico WHERE nome = @Servico) 
        AND DATA_AGENDAMENTO = @Data 
        AND HORA_AGENDAMENTO = @Hora";

            using (MySqlCommand cmdVerificar = new MySqlCommand(sqlVerificar, bd.conecta))
            {
                cmdVerificar.Parameters.AddWithValue("@Funcionario", cbFunc.Text);
                cmdVerificar.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                cmdVerificar.Parameters.AddWithValue("@Servico", cbServico.Text);
                cmdVerificar.Parameters.AddWithValue("@Data", dtAgendamento.Value.Date);
                cmdVerificar.Parameters.AddWithValue("@Hora", cbHora.Text);

                int count = Convert.ToInt32(cmdVerificar.ExecuteScalar());

                return count > 0;
            }
        }

        private void cbServico_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Obtém o preço do serviço selecionado
            DataRowView selectedService = cbServico.SelectedItem as DataRowView;
            if (selectedService != null)
            {
                string preco = selectedService["preco"].ToString();
                tbPreco.Text = preco;
            }
        }


    }
}




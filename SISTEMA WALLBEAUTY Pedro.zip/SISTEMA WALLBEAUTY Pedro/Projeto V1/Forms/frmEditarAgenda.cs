﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarAgenda : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;

        public frmEditarAgenda()
        {
            InitializeComponent();
            busca();
            FillCliente();
            FillServico();
            FillFuncionario();
        }

        //------------------------------------------------------------funções---------------------------------------------------------
        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Funcionario.NOME AS Funcionário, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id ";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }


        private void FillCliente()
        {
            bd.abrirConn();
            string sql = "select nome from cliente";
            MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);

            cbCliente.DataSource = dt.Copy(); // Copia o DataTable para cbCliente
            cbCliente.DisplayMember = "nome";

            cbBusca.DataSource = dt.Copy(); // Copia o DataTable para cbBusca
            cbBusca.DisplayMember = "nome";
        }





        //-----------------------------------------------------crud do form----------------------------------------------------------

        //buscar
        private void btnSelect_Click_1(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.Id as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Agendamento.HORA_AGENDAMENTO as Hora, Funcionario.NOME AS Funcionário, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id " +
                  "WHERE cliente.NOME = @BuscaCliente";

            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@BuscaCliente", cbBusca.Text);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;

        }


        //atualizar dados
        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja alterar as informações do agendamento?", "Dados atualizados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();

                // Verifica se todos os campos são diferentes
                if (cbFunc.Text == cbServico.Text || cbFunc.Text == cbCliente.Text || cbServico.Text == cbCliente.Text)
                {
                    MessageBox.Show("Por favor, selecione valores diferentes para cada campo.");
                    return; // Sai do método sem atualizar o agendamento
                }

                // Verifica se já existe um agendamento com os mesmos dados
                string sqlVerificar = @"
            SELECT COUNT(*) 
            FROM agendamento 
            WHERE FUNCIONARIO_ID = (SELECT ID FROM funcionario WHERE nome = @Funcionario) 
            AND FK_CLIENTE_ID = (SELECT ID FROM cliente WHERE nome = @Cliente) 
            AND FK_SERVICO_ID = (SELECT ID FROM servico WHERE nome = @Servico) 
            AND DATA_AGENDAMENTO = @Data 
            AND HORA_AGENDAMENTO = @Hora";

                using (MySqlCommand cmdVerificar = new MySqlCommand(sqlVerificar, bd.conecta))
                {
                    cmdVerificar.Parameters.AddWithValue("@Funcionario", cbFunc.Text);
                    cmdVerificar.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                    cmdVerificar.Parameters.AddWithValue("@Servico", cbServico.Text);
                    cmdVerificar.Parameters.AddWithValue("@Data", dtAgendamento.Value.Date);
                    cmdVerificar.Parameters.AddWithValue("@Hora", TimeSpan.Parse(cbHora.SelectedItem.ToString()));

                    int count = Convert.ToInt32(cmdVerificar.ExecuteScalar());

                    if (count > 0)
                    {
                        MessageBox.Show("Já existe um agendamento com esses dados.");
                        return; // Sai do método sem atualizar o agendamento
                    }
                }

                // Atualiza o agendamento
                sql = @"UPDATE agendamento
                SET agendamento.FUNCIONARIO_ID = (SELECT f.ID FROM funcionario f WHERE f.nome = @Func),
                    agendamento.FK_CLIENTE_ID = (SELECT c.ID FROM cliente c WHERE c.nome = @Cliente),
                    agendamento.FK_SERVICO_ID = (SELECT s.ID FROM servico s WHERE s.nome = @Serv),           
                    agendamento.DATA_AGENDAMENTO = @DataAgenda,
                    agendamento.HORA_AGENDAMENTO = @HoraAgenda            
                WHERE agendamento.ID = @Id";

                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@Func", cbFunc.Text);
                cmd.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                cmd.Parameters.AddWithValue("@Serv", cbServico.Text);
                cmd.Parameters.AddWithValue("@DataAgenda", dtAgendamento.Value);
                cmd.Parameters.AddWithValue("@HoraAgenda", TimeSpan.Parse(cbHora.SelectedItem.ToString()));
                cmd.Parameters.AddWithValue("@Id", lbId.Text);
                cmd.ExecuteNonQuery();

                busca();
            }
        }



        //deletar
        private void btnCancel_Click_1(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja cancelar o serviço?", "Serviço cancelado.", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes && lbStatus.Text == "Concluído")
            {
                MessageBox.Show("O serviço selecionado já foi concluído.");
            }
            else
            {
                bd.abrirConn();
                sql = "update agendamento set STATUS= 'Cancelado' where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lbId.Text);
                cmd.ExecuteNonQuery();
                busca();
            }
        }

        private void btnConcluir_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("O serviço selecionado será dado como concluído, continuar?", "Serviço concluído.", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes && lbStatus.Text == "Concluído")
            {
                MessageBox.Show("O serviço selecionado já foi concluído.");
            }
            else
            {
                bd.abrirConn();
                sql = "update agendamento set STATUS= 'Concluído' where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lbId.Text);
                cmd.ExecuteNonQuery();
                busca();
            }
        }

        //reseta o datagridview, voltando a mostrar todos os agendamentos (caso tenha apertado o "buscar" e queira voltar atrás)
        private void btnReset_Click_1(object sender, EventArgs e)
        {
            busca();

        }






        private void dtBusca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;


                btnSelect.PerformClick();
            }
        }

        private void frmEditarAgenda_Load(object sender, EventArgs e)
        {



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                string hora = row.Cells["Hora"].Value.ToString();
                string[] horariosAgendados = hora.Split(':');

                cbHora.Items.Clear();

                // Adiciona apenas os horários disponíveis ao ComboBox
                foreach (var horario in ObterHorariosDisponiveis())
                {
                    cbHora.Items.Add(horario);
                }

                // Adiciona o horário selecionado ao ComboBox
                cbHora.Items.Add(hora);

                // Preenche os ComboBoxes com os dados do banco de dados
                FillServico();
                FillFuncionario();
                FillCliente();

                // Seleciona o horário do conteúdo selecionado no DataGridView
                cbHora.SelectedItem = hora;

                // Preenche outros ComboBoxes com base nos dados da linha selecionada
                string servico = row.Cells["SERVIÇO"].Value.ToString();
                cbServico.Enabled = true;
                int indexServico = cbServico.FindStringExact(servico);
                cbServico.SelectedIndex = indexServico;

                string funcionario = row.Cells["FUNCIONÁRIO"].Value.ToString();
                cbFunc.Enabled = true;
                int indexFuncionario = cbFunc.FindStringExact(funcionario);
                cbFunc.SelectedIndex = indexFuncionario;

                string cliente = row.Cells["CLIENTE"].Value.ToString();
                cbCliente.Enabled = true;
                int indexCliente = cbCliente.FindStringExact(cliente);
                cbCliente.SelectedIndex = indexCliente;

                string valor = row.Cells["PREÇO"].Value.ToString();
                tbValor.Text = valor;
            }
        }


        private List<string> ObterHorariosDisponiveis()
        {
            // Implementa a lógica para obter todos os horários disponíveis
            // Consulta o banco de dados para encontrar todos os horários disponíveis para agendamento.

            List<string> horarios = new List<string>();

            // Adiciona todos os horários possíveis
            horarios.Add("07:00:00");
            horarios.Add("08:00:00");
            horarios.Add("09:00:00");
            horarios.Add("10:00:00");
            horarios.Add("11:00:00");
            horarios.Add("13:00:00");
            horarios.Add("14:00:00");
            horarios.Add("15:00:00");
            horarios.Add("16:00:00");
            horarios.Add("17:00:00");
            horarios.Add("18:00:00");
            horarios.Add("19:00:00");

            // Consulta o banco de dados para obter os horários já agendados
            List<string> horariosAgendados = ConsultarHorariosAgendados();

            // Remove os horários já agendados da lista de horários disponíveis
            foreach (var horarioAgendado in horariosAgendados)
            {
                if (horarios.Contains(horarioAgendado))
                {
                    horarios.Remove(horarioAgendado);
                }
            }

            return horarios;
        }

        private List<string> ConsultarHorariosAgendados()
        {
            // Implementa a lógica para consultar o banco de dados e obter os horários já agendados
            // Retorna uma lista de horários já agendados
            // Supõe-se que existe uma tabela 'Agendamentos' com um campo 'Hora_Agendamento'

            List<string> horariosAgendados = new List<string>();

            bd.abrirConn();
            sql = "SELECT Hora_agendamento FROM Agendamento WHERE Data_agendamento = @Data";
            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@Data", dtAgendamento.Value.Date);

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string horaAgendada = reader["Hora_Agendamento"].ToString();
                    horariosAgendados.Add(horaAgendada);
                }
            }

            return horariosAgendados;
        }



    }
}